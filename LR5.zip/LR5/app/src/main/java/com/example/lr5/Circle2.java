package com.example.lr5;

public class Circle2 extends Shape2{
    protected double radius;

    public Circle2() {
        radius = 5.5;
    }

    public Circle2(double radius) {
        this.radius = radius;
    }

    public Circle2 (double radius, String color, boolean filled) {
        super(color, filled);
        this.radius = radius;
    }

    public double getRadius() {
        return radius;
    }

    public void setRadius(double radius) {
        this.radius = radius;
    }

    @Override
    public double getArea() {
        return 3.14 * radius * radius;
    }

    @Override
    public double getPerimeter() {
        return 2 * 3.14 * radius;
    }

    @Override
    public String toString() {
        return "The circle with color: " + getColor() + ", radius: " + radius + ", area: " + getArea()
                + ", and perimeter: " + getPerimeter() + ", filled status: " + isFilled();
    }

}
