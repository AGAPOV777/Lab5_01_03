package com.example.lr5;

public interface Movable {
    public void moveUP();
    public void moveDown();
    public void moveLeft();
    public void moveRight();

}
